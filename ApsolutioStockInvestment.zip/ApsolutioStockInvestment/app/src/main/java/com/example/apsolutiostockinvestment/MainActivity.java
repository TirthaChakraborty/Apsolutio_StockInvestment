package com.example.apsolutiostockinvestment;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.CompoundButton;

import butterknife.OnCheckedChanged;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //set ActionBar
        ActionBar actionBar = getSupportActionBar(); // or getActionBar();
        getSupportActionBar().setTitle("Portfolio");
    }


    @OnCheckedChanged({R.id.overview, R.id.stocks,R.id.mf,R.id.ulip})
    public void onRadioButtonCheckChanged(CompoundButton button, boolean checked) {
        Intent in;
        if(checked) {
            switch (button.getId()) {
                case R.id.overview:
                    // do stuff
                    break;
                case R.id.stocks:

                    in = new Intent(MainActivity.this, Test.class);
                    startActivity(in);

                    break;
                case R.id.mf:
                    // do stuff
                    break;
                case R.id.ulip:
                    // do stuff
                    break;
            }
        }
    }
}
